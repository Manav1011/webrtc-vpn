package main

import (
	"crypto/tls"
	"errors"
	"flag"
	"io"
	"log"
	"net/url"
	"os"
	"os/signal"

	"webrtc-vpn-go/pkg/signaling"

	"github.com/gorilla/websocket"
	"github.com/pion/webrtc/v3"
	"github.com/songgao/water"
)

func main() {
	roomID := flag.String("room", "", "Room ID for signaling")
	flag.Parse()

	if *roomID == "" {
		log.Fatal("Room ID is required")
	}

	// Configure logger
	log.SetFlags(log.LstdFlags | log.Lshortfile)
	logFile, err := os.OpenFile("answerer.log", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		log.Fatal(err)
	}
	defer logFile.Close()
	log.SetOutput(logFile)

	// Create WebRTC configuration
	config := webrtc.Configuration{
		ICEServers: []webrtc.ICEServer{
			{URLs: []string{"stun:stun.l.google.com:19302"}},
			{URLs: []string{"stun:stun1.l.google.com:19302"}},
			{URLs: []string{"stun:stun2.l.google.com:19302"}},
			{URLs: []string{"stun:stun3.l.google.com:19302"}},
			{URLs: []string{"stun:stun4.l.google.com:19302"}},
		},
	}

	// Create a new RTCPeerConnection
	peerConnection, err := webrtc.NewPeerConnection(config)
	if err != nil {
		log.Fatal(err)
	}
	defer peerConnection.Close()

	// Open the existing TAP interface
	tunConfig := water.Config{
		DeviceType: water.TAP,
		PlatformSpecificParams: water.PlatformSpecificParams{
			Name:    "revpn-answer",
			Persist: true,
		},
	}

	log.Println("Opening existing TAP interface 'revpn-answer'...")
	tap, err := water.New(tunConfig)
	if err != nil {
		log.Printf("Failed to open TAP interface: %v\n", err)
		if os.IsPermission(err) {
			log.Println("Permission denied. Make sure you have the right permissions to access the TAP interface")
		}
		log.Fatal(err)
	}
	defer tap.Close()

	log.Printf("Successfully opened TAP interface: %s\n", tap.Name())

	// Handle incoming data channel
	peerConnection.OnDataChannel(func(dataChannel *webrtc.DataChannel) {
		log.Printf("New DataChannel %s %d\n", dataChannel.Label(), dataChannel.ID())

		dataChannel.OnOpen(func() {
			log.Println("Data channel opened")

			// Start reading from TAP interface
			go func() {
				buffer := make([]byte, 1500) // MTU size
				for {
					n, err := tap.Read(buffer)
					if err != nil {
						if !errors.Is(err, io.EOF) {
							log.Printf("Error reading from TAP: %v\n", err)
						}
						continue
					}
					if n > 0 {
						log.Printf("Read %d bytes from TAP\n", n)
						// Create a copy of the data to avoid race conditions
						data := make([]byte, n)
						copy(data, buffer[:n])
						if err := dataChannel.Send(data); err != nil {
							log.Printf("Error sending data: %v\n", err)
						}
					}
				}
			}()
		})

		dataChannel.OnMessage(func(msg webrtc.DataChannelMessage) {
			if _, err := tap.Write(msg.Data); err != nil {
				log.Printf("Error writing to TAP: %v\n", err)
			} else {
				log.Printf("Wrote %d bytes to TAP\n", len(msg.Data))
			}
		})

		// Handle data channel state changes
		dataChannel.OnClose(func() {
			log.Println("Data channel closed")
		})

		dataChannel.OnError(func(err error) {
			log.Printf("Data channel error: %v\n", err)
		})
	})

	// Connect to signaling server
	u := url.URL{Scheme: "wss", Host: "webrtc-vpn.mnv-dev.site"}
	dialer := websocket.Dialer{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}

	c, _, err := dialer.Dial(u.String(), nil)
	if err != nil {
		log.Fatal("dial:", err)
	}
	defer c.Close()

	// Register as answerer
	register := signaling.Message{
		Type: "register",
		Role: "answerer",
		Room: *roomID,
	}
	if err := c.WriteJSON(register); err != nil {
		log.Fatal(err)
	}

	// Handle ICE candidates
	peerConnection.OnICECandidate(func(ice *webrtc.ICECandidate) {
		if ice == nil {
			return
		}
		iceJSON := ice.ToJSON()
		candidateMsg := signaling.Message{
			Type:      "candidate",
			Target:    "offerer",
			Candidate: &iceJSON,
		}
		if err := c.WriteJSON(candidateMsg); err != nil {
			log.Printf("Error sending ICE candidate: %v", err)
		}
	})

	// Connection state handling
	peerConnection.OnConnectionStateChange(func(state webrtc.PeerConnectionState) {
		log.Printf("Connection state changed: %s", state.String())
	})

	// Handle incoming messages from signaling server
	done := make(chan struct{})
	go func() {
		for {
			var msg signaling.Message
			err := c.ReadJSON(&msg)
			if err != nil {
				log.Println("read:", err)
				close(done)
				return
			}

			switch msg.Type {
			case "offer":
				offer := webrtc.SessionDescription{
					Type: webrtc.SDPTypeOffer,
					SDP:  msg.SDP,
				}

				err = peerConnection.SetRemoteDescription(offer)
				if err != nil {
					log.Printf("Error setting remote description: %v", err)
					continue
				}

				answer, err := peerConnection.CreateAnswer(nil)
				if err != nil {
					log.Printf("Error creating answer: %v", err)
					continue
				}

				err = peerConnection.SetLocalDescription(answer)
				if err != nil {
					log.Printf("Error setting local description: %v", err)
					continue
				}

				answerMsg := signaling.Message{
					Type:   "answer",
					Target: "offerer",
					SDP:    answer.SDP,
				}
				if err := c.WriteJSON(answerMsg); err != nil {
					log.Printf("Error sending answer: %v", err)
				}

			case "candidate":
				if msg.Candidate != nil {
					err := peerConnection.AddICECandidate(*msg.Candidate)
					if err != nil {
						log.Printf("Error adding ICE candidate: %v", err)
					}
				}
			}
		}
	}()

	// Wait for interrupt signal
	interrupt := make(chan os.Signal, 1)
	signal.Notify(interrupt, os.Interrupt)

	select {
	case <-done:
		log.Println("Connection closed")
	case <-interrupt:
		log.Println("Interrupted")
		if err := c.WriteMessage(
			websocket.CloseMessage,
			websocket.FormatCloseMessage(websocket.CloseNormalClosure, ""),
		); err != nil {
			log.Printf("Error closing connection: %v", err)
		}
	}
}
